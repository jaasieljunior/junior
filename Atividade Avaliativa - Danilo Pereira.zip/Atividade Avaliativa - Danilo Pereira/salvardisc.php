<?php
    $nome = filter_input(INPUT_GET, "nome");
    $professor = filter_input(INPUT_GET, "professor");
     
    $link = mysqli_connect("localhost","root","","turma");
     
    if($link){
        $query = mysqli_query($link,"insert into disciplina values ('','$nome','$professor');");
        if($query){
            header("Location: disciplina.php");
        }else{
            die("Error: " . mysqli_error($link));
        }
    }else{
        die("Error: " . mysqli_error($link));
    }
?>