<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Alterar Sala</title>
        <?php
            $id= filter_input(INPUT_GET,"id");
            $cod= filter_input(INPUT_GET,"cod");
            $horario= filter_input(INPUT_GET,"horario");
			$vago= filter_input(INPUT_GET,"vago");
        ?>
    </head>
    <body>
        <div>
            <h1>Alterar Sala</h1>
                <form action="altsala.php">
                    <input type="hidden" name="id" value="<?php echo $id ?>"/>
                    Cod: <input type="text" name="cod" value="<?php echo $cod ?>"/><br/>
                    Horario: <input type="text" name="horario" value="<?php echo $horario ?>"/><br/>
					Vago: <input type="text" name="vago" value="<?php echo $vago ?>"/><br/>
                    <input type="submit" value="Alterar"/>
                </form>
        </div>
    </body>
</html>