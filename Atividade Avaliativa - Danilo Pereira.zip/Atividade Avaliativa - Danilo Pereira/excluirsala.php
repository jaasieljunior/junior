<?php
     
    $id = filter_input(INPUT_GET,"id");
     
    $link = mysqli_connect("localhost","root","","turma");
     
    if($link){
        $query = mysqli_query($link, "delete from sala where id='$id';");
        if($query){
            header("Location: sala.php");
    }else{
        die("Error: " . mysqli_error($link));
    }       
    }else{
        die("Error: " . mysqli_error($link));
    }
     
?>