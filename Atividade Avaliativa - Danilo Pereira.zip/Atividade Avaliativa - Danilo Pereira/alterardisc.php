<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Alterar Sala</title>
        <?php
            $id= filter_input(INPUT_GET,"id");
            $nome= filter_input(INPUT_GET,"nome");
            $professor= filter_input(INPUT_GET,"professor");
        ?>
    </head>
    <body>
        <div>
            <h1>Alterar Sala</h1>
                <form action="altdisc.php">
                    <input type="hidden" name="id" value="<?php echo $id ?>"/>
                    Nome: <input type="text" name="nome" value="<?php echo $nome ?>"/><br/>
                    Professor: <input type="text" name="professor" value="<?php echo $professor ?>"/><br/>
                    <input type="submit" value="Alterar"/>
                </form>
        </div>
    </body>
</html>