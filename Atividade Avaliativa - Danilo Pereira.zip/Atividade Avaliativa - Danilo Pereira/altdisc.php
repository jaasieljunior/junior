<?php
    $id = filter_input(INPUT_GET, "id");
    $nome = filter_input(INPUT_GET, "nome");
    $professor = filter_input(INPUT_GET, "professor");
     
    $link = mysqli_connect("localhost","root","","turma");
         
        if($link){
            $query = mysqli_query($link,"update disciplina set nome='$nome', professor='$professor' where id='$id';");
            if($query){
                header("Location: disciplina.php");
            }else{
                die("Erro: " . mysqli_error($link));
            }
        }else{
            die("Erro: " . mysqli_error($link));
        }
?>