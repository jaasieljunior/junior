<?php
    $cod = filter_input(INPUT_GET, "cod");
    $horario = filter_input(INPUT_GET, "horario");
	$vago = filter_input(INPUT_GET, "vago");
     
    $link = mysqli_connect("localhost","root","","turma");
     
    if($link){
        $query = mysqli_query($link,"insert into sala values ('','$cod','$horario','$vago');");
        if($query){
            header("Location: sala.php");
        }else{
            die("Error: " . mysqli_error($link));
        }
    }else{
        die("Error: " . mysqli_error($link));
    }
?>