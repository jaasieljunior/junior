<?php
    $id = filter_input(INPUT_GET, "id");
    $cod = filter_input(INPUT_GET, "cod");
    $horario = filter_input(INPUT_GET, "horario");
	$vago = filter_input(INPUT_GET, "vago");
     
    $link = mysqli_connect("localhost","root","","turma");
         
        if($link){
            $query = mysqli_query($link,"update sala set cod='$cod', horario='$horario', vago='$vago' where id='$id';");
            if($query){
                header("Location: sala.php");
            }else{
                die("Erro: " . mysqli_error($link));
            }
        }else{
            die("Erro: " . mysqli_error($link));
        }
?>