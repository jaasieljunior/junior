<!DOCTYPE html>
<html>
	<head>
        <title>Sala</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <?php 
            $parametro = filter_input(INPUT_GET, "parametro");
            $mysqllink = mysql_connect("localhost","root","") or die ("Erro ao Conectar com o Servidor");
            mysql_select_db("turma");
             
            if($parametro){
                $dados = mysql_query("select * from sala where cod like '$parametro%' order by cod");
            }else{
                $dados = mysql_query("select * from sala order by cod");
            }
             
            $linha = mysql_fetch_assoc($dados);
            $total = mysql_num_rows($dados);
             
        ?>
    </head>
	  <body>
        <div>
            <h1>Sala</h1>
            <p>
                <form action="<?php echo $_SERVE['PHP_SELF'];?>">
                    <input type="text" name="parametro"/>
                    <input type="submit" value="Buscar"/>
                </form>
            </p>
            <p>
                <a href="novasala.php">Adicionar nova</a>
            </p>
            <table border="1">
                <tr>
                    <td>Id</td>
                    <td>Cod</td>
                    <td>Horario</td>
					<td>Vago</td>
                </tr>
                <?php 
                    if($total){ do{
                         
                ?>
                    <tr>  
                        <td><?php echo $linha['id'] ?></td>
                        <td><?php echo $linha['cod'] ?></td>
                        <td><?php echo $linha['horario'] ?></td>
						<td><?php echo $linha['vago'] ?></td>
                        <td><a href="<?php echo "alterarsala.php?id=" . $linha['id'] . "&cod=" . $linha['cod'] . "&horario=" . $linha['horario'] . "&vago=" .$linha['vago'] ?>">Alterar</a></td>
                        <td><a href="<?php echo "excluirsala.php?id=" . $linha['id'] ?>">Excluir</a></td>
                    </tr>
                <?php
                    } while($linha = mysql_fetch_assoc($dados));
                     
                    mysql_free_result($dados);}
                     
                    mysql_close($mysqllink);
                ?>
            </table>
        </div>
    </body>
</html>